<?php
/*
Plugin Name: Fullres Analytics
Text Domain: fullres-wp
Plugin URI: https://docs.fullres.com/integrations/wordpress
Description: Installs Fullres Analytics on your site.
Version: 1.4.3
Author: Fullres, Inc.
Author URI: https://fullres.com/
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

//VERSION
define('FULLRES_PLUGIN_VERSION', '1.4.3');


// PREVENT DIRECT ACCESS
if (!defined('ABSPATH')) {
    exit;
}

//UNINSTALL FULLRES
function fullres_uninstall() {
    delete_option('fullres_site_key');
    delete_option('fullres_track_search_events');
    delete_option('fullres_track_comment_events');
    delete_option('fullres_track_register_events');
    delete_option('fullres_track_login_events');
    delete_option('fullres_track_404_events');
    delete_option('fullres_event_scripts');
    delete_option('fullres_log_author_metadata');
    delete_option('fullres_log_category_metadata');
    delete_option('fullres_using_cloudflare_proxy');
    delete_option('fullres_your_domain');
    delete_option('fullres_custom_path_name');
    delete_option('fullres_track_scrolled_full_page_events');
	delete_option('fullres_using_custom_domain');
	delete_option('fullres_custom_domain');

}
register_uninstall_hook(__FILE__, 'fullres_uninstall');

//ACTIVATION SETUP
function fullres_activate() {
    if (get_option('fullres_site_key') === false) {
        update_option('fullres_site_key', '');
    }
    if (get_option('fullres_log_author_metadata') === false) {
        update_option('fullres_log_author_metadata', '1'); // Default to "on"
    }
    if (get_option('fullres_event_scripts') === false) {
        update_option('fullres_event_scripts', '');
    }
    if (get_option('fullres_track_search_events') === false) {
        update_option('fullres_track_search_events', '1'); // Default to "on"
    }
    if (get_option('fullres_track_comment_events') === false) {
	    update_option('fullres_track_comment_events', '1'); // Default to "on"
	}
    if (get_option('fullres_track_register_events') === false) {
	    update_option('fullres_track_register_events', '1'); // Default to "on"
	}
    if (get_option('fullres_track_login_events') === false) {
        update_option('fullres_track_login_events', '1'); // Default to "on"
    }
    if (get_option('fullres_track_404_events') === false) {
        update_option('fullres_track_404_events', '1'); // Default to "on"
    }
    if (get_option('fullres_track_scrolled_full_page_events') === false) {
	    update_option('fullres_track_scrolled_full_page_events', '1'); // Default to "on"
	}
    if (get_option('fullres_log_category_metadata') === false) {
        update_option('fullres_log_category_metadata', '1'); // Default to "on"
    }
    if (get_option('fullres_using_cloudflare_proxy') === false) {
        update_option('fullres_using_cloudflare_proxy', '0'); // Default to "off"
    }
    if (get_option('fullres_your_domain') === false) {
        update_option('fullres_your_domain', '');
    }
    if (get_option('fullres_custom_path_name') === false) {
        update_option('fullres_custom_path_name', '');
    }
	if (get_option('fullres_using_custom_domain') === false) {
        update_option('fullres_using_custom_domain', '0');  // Default to "off"
    }
	if (get_option('fullres_custom_domain') === false) {
        update_option('fullres_custom_domain', '');
    }
}
register_activation_hook(__FILE__, 'fullres_activate');


//INSTALL
function fullres_install() {
	
	//SETUP SCRIPT
    wp_register_script('fullres-custom-js', false, array(), '1.0.0', false);
    wp_enqueue_script('fullres-custom-js');

	//GET OPTIONS
    $fullresKey = get_option('fullres_site_key', 'default_site_key');
    $usingCloudflareProxy = get_option('fullres_using_cloudflare_proxy', '0');
    $yourDomain = get_option('fullres_your_domain', '');
    $customPathName = get_option('fullres_custom_path_name', '');
	$trackSearchEvents = get_option('fullres_track_search_events', '0');
	$trackCommentEvents = get_option('fullres_track_comment_events', '0');
	$trackScrolledFullPageEvents = get_option('fullres_track_scrolled_full_page_events', '0');
	$trackRegisterEvents = get_option('fullres_track_register_events', '0');
	$trackLoginEvents = get_option('fullres_track_login_events', '0');
	$track404Events = get_option('fullres_track_404_events', '0');
	$eventScripts = get_option('fullres_event_scripts', '');
	$usingCustomDomain = get_option('fullres_using_custom_domain', '0');
	$customDomain = get_option('fullres_custom_domain', '');
	$customDomain = rtrim($customDomain, '/'); // Ensure there is no trailing slash

	// script setup and determine which domain to use based on custom domain and cloudflare options
	if ($usingCustomDomain === '1' && !empty($customDomain)) {
		$mainScript = "(function(){
			var fullres = document.createElement('script');
			fullres.async = true;
			fullres.src = 'https://" . esc_js($customDomain) . "/" . esc_js($fullresKey) . ".js?'+(new Date()-new Date()%43200000);
			document.head.appendChild(fullres);
		})();";
	} else if ($usingCloudflareProxy === '1' && !empty($yourDomain) && !empty($customPathName)) {
		$mainScript = "(function(){
			var fullres = document.createElement('script');
			fullres.async = true;
			fullres.src = 'https://" . esc_js($yourDomain) . "/" . esc_js($customPathName) . "/" . esc_js($fullresKey) . ".js?'+(new Date()-new Date()%43200000);
			fullres.setAttribute('siteKeyOverride', '" . esc_js($fullresKey) . "');
			document.head.appendChild(fullres);
		})();";
	} else {
		// Default script setup without Custom Domain or Cloudflare proxy
		$mainScript = "(function(){
			var fullres = document.createElement('script');
			fullres.async = true;
			fullres.src = 'https://t.fullres.net/" . esc_js($fullresKey) . ".js?'+(new Date()-new Date()%43200000);
			document.head.appendChild(fullres);
		})();";
	}   

   //SET EVENTS + METADATA ARRAY
   $mainScript .= 'window.fullres ||= { events: [], metadata: {} }; window.fullres.metadata._wp_plugin = "' . esc_js(FULLRES_PLUGIN_VERSION) . '";';
   

	//ADD SCRIPT
    wp_add_inline_script('fullres-custom-js', $mainScript);

    //SINGLE POST?
    if (is_single()) {
	    
	    //CHECK AUTHOR OR CATEGORY METADATA
	    $logAuthorMetadata = get_option('fullres_log_author_metadata', '1');
	    $logCategoryMetadata = get_option('fullres_log_category_metadata', '1');
	    if ($logAuthorMetadata === '1' || $logCategoryMetadata === '1') {
	    
		    //SET SCRIPT
	        $metadataScript = 'window.fullres ||= { events: [], metadata: {} };';
			
			//AUTHOR METADATA?
	        if ($logAuthorMetadata === '1') {
	            global $post;
	            $author_id = get_post_field('post_author', $post->ID);
	            $author_display_name = get_the_author_meta('display_name', $author_id);
	            $metadataScript .= 'window.fullres.metadata.postAuthor = "' . esc_js($author_id) . '-' . esc_js($author_display_name) . '";';
	        }
			
			//CATEGORY METADATA?
	        if ($logCategoryMetadata === '1') {
	            $categories = get_the_category($post->ID);
	            if (!empty($categories)) {
	                $category = $categories[0];
	                $category_id = $category->term_id;
	                $category_name = $category->name;
	                $metadataScript .= 'window.fullres.metadata.postCategory = "' . esc_js($category_id) . '-' . esc_js($category_name) . '";';
	            }
	        }
			
			//ADD SCRIPTs
	        wp_add_inline_script('fullres-custom-js', $metadataScript);
        }
    }
    
    //NOT ADMIN? + IS LOGGED IN
    if (!is_admin()) {

	    //GET IS LOGGED IN METADATA
	    $trackLoggedInStatus = get_option('fullres_track_logged_in_status', '1');  // Default to "on"
	
	    //CHECK ENABLED...
	    if ($trackLoggedInStatus === '1') {
	        $isLoggedIn = is_user_logged_in() ? 'true' : 'false';
	
	        $loggedInStatusScript = 'window.fullres ||= { events: [], metadata: {} };';
	        $loggedInStatusScript .= 'window.fullres.metadata.isLoggedIn = "' . esc_js($isLoggedIn) . '";';
	
	        //ADD SCRIPT
	        wp_add_inline_script('fullres-custom-js', $loggedInStatusScript);
	    }
	}

    
    //SEARCH EVENTS SCRIPT
    if ($trackSearchEvents === '1') {
	    
	    //SET SCRIPT
        $searchEventScript = "document.addEventListener('DOMContentLoaded', () => {
			let searchForms = document.querySelectorAll('#searchform');
			if (searchForms.length === 0) { searchForms = document.querySelectorAll('.searchform'); }
			searchForms.forEach((searchForm) => {
			    searchForm.addEventListener('submit', (event) => {
			        let searchInput = searchForm.querySelector('input[name=\"s\"]') || searchForm.querySelector('input[type=\"text\"]');
				    const searchInputValue = searchInput ? searchInput.value : '';
				    if(searchInputValue !== ''){
				        window.fullres.events.push({ key: 'searchSubmit', searchedFor: searchInputValue });
				    } else {
				        window.fullres.events.push({ key: 'searchSubmit' });
				    }
				   
			    });
			});

        });";
        
        //ADD SCRIPT
        wp_add_inline_script('fullres-custom-js', $searchEventScript);
    }
    
	// COMMENT EVENT SCRIPT
	if ($trackCommentEvents === '1') {
	    // CHECK COMMENT TRANSIENT
	    $commentId = get_transient('fullres-comment-event') ? get_transient('fullres-comment-event') : '';
	    if ($commentId !== '') {
		    
	        // SET SCRIPT
	        $commentEventScript = "document.addEventListener('DOMContentLoaded', function() {
			    window.fullres ||= { events: [] }; 
			    window.fullres.events.push({ key: 'newComment', comment_id: '$commentId'}); 
			});";
	
	        // ADD SCRIPT
	        wp_add_inline_script('fullres-custom-js', $commentEventScript);
	
	        // DELETE TRANSIENT
	        delete_transient('fullres-comment-event');
	    }
	}
	
	//SCROLLED FULL PAGE EVENT
	if ($trackScrolledFullPageEvents === '1' && !is_admin()) {
	    $scrolledFullPageEventScript = "
		document.addEventListener('DOMContentLoaded', function() {
		    // Create a target element at the end of the body
		    var target = document.createElement('div');
		    target.id = 'fullres-scroll-target';
		    document.body.appendChild(target);
		
		    // Set up the IntersectionObserver
		    var observer = new IntersectionObserver(function(entries, observer) {
		        entries.forEach(function(entry) {
		            if (entry.isIntersecting) {
		                window.fullres = window.fullres || { events: [], metadata: {} };
		                window.fullres.events.push({ key: 'scrolledFullPage' });
		                observer.disconnect();
		            }
		        });
		    }, { root: null, rootMargin: '0px', threshold: 0 });
		
		    observer.observe(target);
		});
		";
		
		wp_add_inline_script('fullres-custom-js', $scrolledFullPageEventScript);
	}


	//NEW USER EVENT SCRIPT
	if ($trackRegisterEvents === '1') {
		
	    //CHECK NEW USER ID
	    $registerUserId = get_transient('fullres-register-event');
	    if($registerUserId){

		    //SET SCRIPT
		    $registerEventScript = "document.addEventListener('DOMContentLoaded', function() { 
		        window.fullres = window.fullres || { events: [] }; 
		        window.fullres.events.push({ key: 'newUser', user_id: '$registerUserId' }); 
		    });";
		    
		    //ADD SCRIPT
		    wp_add_inline_script('fullres-custom-js', $registerEventScript);
		    
		    //DELETE TRANSIENT
		    delete_transient('fullres-register-event');
	    }
	}
    
    //LOGIN EVENT SCRIPT
	if ($trackLoginEvents === '1') {
	    
	    //LOGIN TRANSIENT CHECK
	    $loginTransient = get_transient('fullres-login-event');
	    if ($loginTransient) {
		    
		    //SET SCRIPT
	        $loginEventScript = "document.addEventListener('DOMContentLoaded', () => { window.fullres ||= { events: [] }; window.fullres.events.push({ key: 'login', user_id: '$loginTransient' }); });";
			
	        //ADD SCRIPT
	        wp_add_inline_script('fullres-custom-js', $loginEventScript);
	        
	        //DELETE TRANSIENT
	        delete_transient('fullres-login-event');
	    }
	}

	//404 EVENT SCRIPT
	if ($track404Events === '1') {
	
	    //IS 404 PAGE TEMPLATE
	    if (is_404()) {
		    
		    //SET SCRIPT
	        $f04EventScript = "document.addEventListener('DOMContentLoaded', () => { window.fullres ||= { events: [] }; window.fullres.events.push({ key: '404' });});";
			
	        //ADD SCRIPT
	        wp_add_inline_script('fullres-custom-js', $f04EventScript);
	    }
	}
	
    //CUSTOM EVENT SCRIPTS
	if (!empty($eventScripts)) {
		
		//GET SCRIPTS
	    $cleaned_eventScripts = htmlspecialchars_decode(wp_strip_all_tags($eventScripts), ENT_QUOTES);
	
	    //CHECK DOM CONTENT LOADED STATUS
	    $containsDomReady = preg_match('/document\.addEventListener\(\s*[\'"]DOMContentLoaded[\'"]|window\.addEventListener\(\s*[\'"]load[\'"]|\$\(\s*document\s*\)\.ready/', $cleaned_eventScripts);
	    if (!$containsDomReady) {
	        $cleaned_eventScripts = "document.addEventListener('DOMContentLoaded', function() {{$cleaned_eventScripts}});";
	    }
	
	    //ADD SCRIPT
	    wp_add_inline_script('fullres-custom-js', $cleaned_eventScripts);
	}
}
add_action('wp_enqueue_scripts', 'fullres_install');
add_action('admin_enqueue_scripts', 'fullres_install');


 // COMMENT EVENT
function fullres_track_comment_event($comment_id, $comment_object) {
    $track_comment_events = get_option('fullres_track_comment_events', '0');
    if ($track_comment_events === '1') {
	    $commentId = $comment_id ? $comment_id : '';
        set_transient('fullres-comment-event', $commentId, 300); // Expires in 30 seconds
    }
}
add_action('wp_insert_comment', 'fullres_track_comment_event', 10, 2);


//LOGIN EVENT
function fullres_track_login_event($user_login, $user) {
    $track_login_events = get_option('fullres_track_login_events', '0');
    if ($track_login_events === '1') {
        $user_id = $user->ID;
        set_transient('fullres-login-event', $user_id, 30); // Expires in x seconds
    }
}
add_action('wp_login', 'fullres_track_login_event', 10, 2);


//NEW USER EVENT
function fullres_track_register_event($user_id) {
	$usersId = $user_id ? $user_id : '';
    $track_register_events = get_option('fullres_track_register_events', '0');
    if ($track_register_events === '1') {
        set_transient('fullres-register-event', $usersId, 30); // Expires in x seconds
    }
}
add_action('user_register', 'fullres_track_register_event', 10, 1);


// ADMIN MENU SETUP
function fullres_add_admin_menu() {
    add_submenu_page(
        'options-general.php',          // Parent slug: WordPress Settings menu
        'Fullres Analytics Settings',   // Page title
        'Fullres Analytics',            // Menu title
        'manage_options',               // Capability
        'fullres_analytics',            // Menu slug
        'fullres_settings_page'         // Function to display the settings page
    );
}
add_action('admin_menu', 'fullres_add_admin_menu');

// ADMIN PAGE SETUP
function fullres_settings_page() {
	
	//VAR SETUP
    $site_domain = wp_parse_url(home_url(), PHP_URL_HOST);
    ?>
    <div class="wrap">
        <h1>Fullres Analytics Settings</h1>
        <form method="post" action="options.php">
            <input type="hidden" id="fullres_site_domain" value="<?php echo esc_attr($site_domain); ?>">
            <?php
            settings_fields('fullres_plugin_options');
            do_settings_sections('fullres_analytics');
            wp_nonce_field('fullres_save_settings', 'fullres_nonce');
            submit_button();
            ?>
        </form>        
    </div>
    <?php
}



// REGISTER SETTINGS
function fullres_register_settings() {
	
	//SVG SETUP
	$walk_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512"><path d="M160 48a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zM126.5 199.3c-1 .4-1.9 .8-2.9 1.2l-8 3.5c-16.4 7.3-29 21.2-34.7 38.2l-2.6 7.8c-5.6 16.8-23.7 25.8-40.5 20.2s-25.8-23.7-20.2-40.5l2.6-7.8c11.4-34.1 36.6-61.9 69.4-76.5l8-3.5c20.8-9.2 43.3-14 66.1-14c44.6 0 84.8 26.8 101.9 67.9L281 232.7l21.4 10.7c15.8 7.9 22.2 27.1 14.3 42.9s-27.1 22.2-42.9 14.3L247 287.3c-10.3-5.2-18.4-13.8-22.8-24.5l-9.6-23-19.3 65.5 49.5 54c5.4 5.9 9.2 13 11.2 20.8l23 92.1c4.3 17.1-6.1 34.5-23.3 38.8s-34.5-6.1-38.8-23.3l-22-88.1-70.7-77.1c-14.8-16.1-20.3-38.6-14.7-59.7l16.9-63.5zM68.7 398l25-62.4c2.1 3 4.5 5.8 7 8.6l40.7 44.4-14.5 36.2c-2.4 6-6 11.5-10.6 16.1L54.6 502.6c-12.5 12.5-32.8 12.5-45.3 0s-12.5-32.8 0-45.3L68.7 398z"/></svg>';
	$brain_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M0 224.2C0 100.6 100.2 0 224 0l24 0c95.2 0 181.2 69.3 197.3 160.2c2.3 13 6.8 25.7 15.1 36l42 52.6c6.2 7.8 9.6 17.4 9.6 27.4c0 24.2-19.6 43.8-43.8 43.8L448 320l0 64c0 35.3-28.7 64-64 64l-64 0 0 32c0 17.7-14.3 32-32 32L96 512c-17.7 0-32-14.3-32-32l0-72.7c0-16.7-6.9-32.5-17.1-45.8C16.6 322.4 0 274.1 0 224.2zM285.3 208l50.7 0c26.5 0 48-21.5 48-48s-21.5-48-48-48c-.9 0-1.8 0-2.7 .1C326.7 93.4 308.9 80 288 80c-8.6 0-16.6 2.2-23.5 6.2C255.9 72.8 241 64 224 64s-31.9 8.8-40.5 22.2c-7-3.9-15-6.2-23.5-6.2c-26.5 0-48 21.5-48 48c-26.5 0-48 21.5-48 48c0 20.9 13.4 38.7 32.1 45.3c0 .9-.1 1.8-.1 2.7c0 26.5 21.5 48 48 48c5.6 0 11-1 16-2.7l0 18.7c0 17.7 14.3 32 32 32s32-14.3 32-32l0-18.7c5 1.8 10.4 2.7 16 2.7c26.5 0 48-21.5 48-48c0-5.6-1-11-2.7-16zM160 176l0 2.7c0 0 0 0-.1 0c0-.9 .1-1.8 .1-2.7z"/></svg>';
	$pencil_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M410.3 231l11.3-11.3-33.9-33.9-62.1-62.1L291.7 89.8l-11.3 11.3-22.6 22.6L58.6 322.9c-10.4 10.4-18 23.3-22.2 37.4L1 480.7c-2.5 8.4-.2 17.5 6.1 23.7s15.3 8.5 23.7 6.1l120.3-35.4c14.1-4.2 27-11.8 37.4-22.2L387.7 253.7 410.3 231zM160 399.4l-9.1 22.7c-4 3.1-8.5 5.4-13.3 6.9L59.4 452l23-78.1c1.4-4.9 3.8-9.4 6.9-13.3l22.7-9.1 0 32c0 8.8 7.2 16 16 16l32 0zM362.7 18.7L348.3 33.2 325.7 55.8 314.3 67.1l33.9 33.9 62.1 62.1 33.9 33.9 11.3-11.3 22.6-22.6 14.5-14.5c25-25 25-65.5 0-90.5L453.3 18.7c-25-25-65.5-25-90.5 0zm-47.4 168l-144 144c-6.2 6.2-16.4 6.2-22.6 0s-6.2-16.4 0-22.6l144-144c6.2-6.2 16.4-6.2 22.6 0s6.2 16.4 0 22.6z"/></svg>';

	register_setting('fullres_plugin_options', 'fullres_site_key', 'sanitize_text_field');
    register_setting('fullres_plugin_options', 'fullres_track_search_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_comment_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_scrolled_full_page_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_register_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_login_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_404_events', 'absint');
    register_setting('fullres_plugin_options', 'fullres_event_scripts', 'sanitize_textarea_field');
    register_setting('fullres_plugin_options', 'fullres_log_author_metadata', 'sanitize_text_field');
    register_setting('fullres_plugin_options', 'fullres_log_category_metadata', 'absint');
    register_setting('fullres_plugin_options', 'fullres_track_logged_in_status', 'absint');
    register_setting('fullres_plugin_options', 'fullres_using_cloudflare_proxy', 'absint');
    register_setting('fullres_plugin_options', 'fullres_your_domain', 'sanitize_text_field');
    register_setting('fullres_plugin_options', 'fullres_custom_path_name', 'sanitize_text_field');
    register_setting('fullres_plugin_options', 'fullres_using_custom_domain', 'absint');
	register_setting('fullres_plugin_options', 'fullres_custom_domain', 'sanitize_text_field');
	
	//MAIN SECTION
    add_settings_section(
	    'fullres_main_section',                 // ID
	    '',                                     // Title
	    'fullres_settings_section_callback',    // Callback
	    'fullres_analytics'                     // Page
	);
	
	//LOGGING SECTION
    add_settings_section(
        'fullres_events_section',             // ID
        '<span style="display: flex; align-items: center;">' . 
	        $walk_svg . 
	        esc_html__('Log Events', 'fullres-wp') . 
	    '</span>', // Section Title with SVG
        'fullres_events_section_callback',    // Callback
        'fullres_analytics'                     // Page
    );
    
    //METADATA SECTION
    add_settings_section(
        'fullres_metadata_section',             // ID
        '<span style="display: flex; align-items: center;">' . 
	        $pencil_svg . 
	        esc_html__('Log Metadata', 'fullres-wp') . 
	    '</span>', // Section Title with SVG
        'fullres_metadata_section_callback',    // Callback
        'fullres_analytics'                     // Page
    );
    
    //ADVANCED SECTION
    add_settings_section(
        'fullres_advanced_section',             // ID
        '<span style="display: flex; align-items: center;">' . 
	        $brain_svg . 
	        esc_html__('Advanced Settings', 'fullres-wp') . 
	    '</span>', // Section Title with SVG
        'fullres_advanced_section_callback',    // Callback
        'fullres_analytics'                     // Page
    );
	
	//MAIN SECTION
	add_settings_field(
	    'fullres_site_key_field',               // ID
	    esc_html__('Site Key', 'fullres-wp'), // Title
	    'fullres_site_key_field_callback',      // Callback
	    'fullres_analytics',                    // Page
	    'fullres_main_section'                  // Section
	);
	
	//SEARCH EVENTS 
	add_settings_field(
        'fullres_track_search_events_field',    // ID
        esc_html__('Searches', 'fullres-wp'), // Title
        'fullres_track_search_events_field_callback', // Callback
        'fullres_analytics',                    // Page
        'fullres_events_section'                  // Section
    );
	
	//COMMENT EVENTS    
    add_settings_field(
	    'fullres_track_comment_events_field',    // ID
	    esc_html__('Comments', 'fullres-wp'), // Title
	    'fullres_track_comment_events_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_events_section'                  // Section
	);
    
    //SCROLLLED FULL PAGE
    add_settings_field(
	    'fullres_track_scrolled_full_page_events_field',    // ID
	    esc_html__('Scrolled Full Page', 'fullres-wp'), // Title
	    'fullres_track_scrolled_full_page_events_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_events_section'                  // Section
	);

    
    //REGISTER EVENTS
	add_settings_field(
	    'fullres_track_register_events_field',    // ID
	    esc_html__('New Users', 'fullres-wp'), // Title
	    'fullres_track_register_events_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_events_section'                  // Section
	);

    
    //LOGIN EVENTS
    add_settings_field(
        'fullres_track_login_events_field',    // ID
        esc_html__('Logins', 'fullres-wp'), // Title
        'fullres_track_login_events_field_callback', // Callback
        'fullres_analytics',                    // Page
        'fullres_events_section'                  // Section
    );
	
	//404 EVENTS
    add_settings_field(
        'fullres_track_404_events_field',    // ID
        esc_html__('404 Errors', 'fullres-wp'), // Title
        'fullres_track_404_events_field_callback', // Callback
        'fullres_analytics',                    // Page
        'fullres_events_section'                  // Section
    );
	
	//CUSTOM EVENT SCRIPTS
	add_settings_field(
	    'fullres_event_scripts_field',          // ID
	    wp_kses_post(__('Custom Event Scripts <small>(optional)</small>', 'fullres-wp')), // Title
	    'fullres_event_scripts_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_events_section'                  // Section
	);

	//POST AUTHOR
	add_settings_field(
	    'fullres_log_author_metadata_field',    // ID
	    esc_html__('Post Author', 'fullres-wp'), // Title
	    'fullres_log_author_metadata_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_metadata_section'                  // Section
	);
	
	//POST CATEGORY
	add_settings_field(
	    'fullres_log_category_metadata_field',  // ID
	    esc_html__('Post Category', 'fullres-wp'), // Title
	    'fullres_log_category_metadata_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_metadata_section'                  // Section
	);
	
	//IS LOGGED IN
	add_settings_field(
	    'fullres_track_logged_in_status_field',   // ID
	    esc_html__('User Logged In Status', 'fullres-wp'),  // Title
	    'fullres_track_logged_in_status_field_callback',    // Callback
	    'fullres_analytics',                      // Page
	    'fullres_metadata_section'                // Section
	);

	//USING CUSTOM DOMAIN
	add_settings_field(
		'fullres_using_custom_domain_field',         // ID
	    wp_kses_post(__('Use a <a target="_blank" href="https://docs.fullres.com/links/custom-domains">Custom Domain</a>', 'fullres-wp')), // Title
		'fullres_using_custom_domain_field_callback', // Callback function
		'fullres_analytics',                    // Page
		'fullres_advanced_section'              // Section
	);

	//CUSTOM DOMAIN FIELD
	add_settings_field(
		'fullres_custom_domain_field',         // ID
	    esc_html__('↳ Custom Domain', 'fullres-wp'), // Title
		'fullres_custom_domain_field_callback', // Callback function
		'fullres_analytics',                    // Page
		'fullres_advanced_section'              // Section
	);
	
	//USING CLOUDFLARE
	add_settings_field(
	    'fullres_using_cloudflare_proxy_field', // ID
	    wp_kses_post(__('Use a <a target="_blank" href="https://docs.fullres.com/analytics/cloudflare-script-proxy">Cloudflare Script Proxy</a>', 'fullres-wp')), // Title
	    'fullres_using_cloudflare_proxy_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_advanced_section'                  // Section
	);
	
	//DOMAIN
	add_settings_field(
	    'fullres_your_domain_field',            // ID
	    esc_html__('↳ Your Domain', 'fullres-wp'), // Title
	    'fullres_your_domain_field_callback',   // Callback
	    'fullres_analytics',                    // Page
	    'fullres_advanced_section'                  // Section
	);
	
	//PATH
	add_settings_field(
	    'fullres_custom_path_name_field',       // ID
	    esc_html__('↳ Your Custom Path Name', 'fullres-wp'), // Title
	    'fullres_custom_path_name_field_callback', // Callback
	    'fullres_analytics',                    // Page
	    'fullres_advanced_section'                  // Section
	);
	
}
add_action('admin_init', 'fullres_register_settings');

	//EMPTY CALLBACK FUNCTIONS

	function fullres_events_section_callback() {}
	function fullres_metadata_section_callback() {}
	function fullres_advanced_section_callback() {}

	//CALLBACK FUNCTIONS
	function fullres_settings_section_callback() {
	    echo '<p><a class="fullres-button" target="_blank" href="https://app.fullres.com/">' . esc_html__('Fullres Dashboard', 'fullres-wp') . '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path d="M320 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l82.7 0L201.4 265.4c-12.5 12.5-12.5 32.8 0 45.3s32.8 12.5 45.3 0L448 109.3l0 82.7c0 17.7 14.3 32 32 32s32-14.3 32-32l0-160c0-17.7-14.3-32-32-32L320 0zM80 32C35.8 32 0 67.8 0 112L0 432c0 44.2 35.8 80 80 80l320 0c44.2 0 80-35.8 80-80l0-112c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 112c0 8.8-7.2 16-16 16L80 448c-8.8 0-16-7.2-16-16l0-320c0-8.8 7.2-16 16-16l112 0c17.7 0 32-14.3 32-32s-14.3-32-32-32L80 32z"/></svg></a></p>'; // &nearr;
	}
	
	function fullres_site_key_field_callback() {
	    $site_key = get_option('fullres_site_key');
	    echo '<input type="text" id="fullres_site_key" name="fullres_site_key" value="' . esc_attr($site_key) . '" />';
	}
	
	function fullres_track_search_events_field_callback() {
	    $track_search_events = get_option('fullres_track_search_events', '0');
	    echo '<input type="checkbox" id="fullres_track_search_events" name="fullres_track_search_events" value="1" ' . checked($track_search_events, '1', false) . ' /> <label for="fullres_track_search_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_track_comment_events_field_callback() {
	    $track_comment_events = get_option('fullres_track_comment_events', '0');
	    echo '<input type="checkbox" id="fullres_track_comment_events" name="fullres_track_comment_events" value="1" ' . checked($track_comment_events, '1', false) . ' /> <label for="fullres_track_comment_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	function fullres_track_scrolled_full_page_events_field_callback() {
	    $track_scrolled_full_page_events = get_option('fullres_track_scrolled_full_page_events', '0');
	    echo '<input type="checkbox" id="fullres_track_scrolled_full_page_events" name="fullres_track_scrolled_full_page_events" value="1" ' . checked($track_scrolled_full_page_events, '1', false) . ' /> <label for="fullres_track_scrolled_full_page_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}

	function fullres_track_register_events_field_callback() {
	    $track_register_events = get_option('fullres_track_register_events', '0');
	    echo '<input type="checkbox" id="fullres_track_register_events" name="fullres_track_register_events" value="1" ' . checked($track_register_events, '1', false) . ' /> <label for="fullres_track_register_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_track_login_events_field_callback() {
	    $track_login_events = get_option('fullres_track_login_events', '0');
	    echo '<input type="checkbox" id="fullres_track_login_events" name="fullres_track_login_events" value="1" ' . checked($track_login_events, '1', false) . ' /> <label for="fullres_track_login_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_track_404_events_field_callback() {
	    $track_404_events = get_option('fullres_track_404_events', '0');
	    echo '<input type="checkbox" id="fullres_track_404_events" name="fullres_track_404_events" value="1" ' . checked($track_404_events, '1', false) . ' /> <label for="fullres_track_404_events">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_event_scripts_field_callback() {
	    $event_scripts = get_option('fullres_event_scripts');
	    // Translators: %s is the URL to the Fullres Docs page.
		echo '<textarea id="fullres_event_scripts" name="fullres_event_scripts" rows="10" cols="50" spellcheck="false">' . esc_textarea($event_scripts) . '</textarea><br><small>' . sprintf(wp_kses_post(__('Visit <a target="_blank" href="%s">Fullres Docs</a> for more info about Events.', 'fullres-wp')), esc_url('https://fr.sh/2a986e')) . '</small>';
	}
	
	function fullres_log_author_metadata_field_callback() {
	    $log_author_metadata = get_option('fullres_log_author_metadata', '1');
	    echo '<input type="checkbox" id="fullres_log_author_metadata" name="fullres_log_author_metadata" value="1" ' . checked($log_author_metadata, '1', false) . ' /> <label for="fullres_log_author_metadata">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_log_category_metadata_field_callback() {
	    $log_category_metadata = get_option('fullres_log_category_metadata', '1');
	    echo '<input type="checkbox" id="fullres_log_category_metadata" name="fullres_log_category_metadata" value="1" ' . checked($log_category_metadata, '1', false) . ' /> <label for="fullres_log_category_metadata">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_track_logged_in_status_field_callback() {
	    $track_logged_in_status = get_option('fullres_track_logged_in_status', '1');  // Default to "on"
	    echo '<input type="checkbox" id="fullres_track_logged_in_status" name="fullres_track_logged_in_status" value="1" ' . checked($track_logged_in_status, '1', false) . ' /> <label for="fullres_track_logged_in_status">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_using_cloudflare_proxy_field_callback() {
	    $using_cloudflare_proxy = get_option('fullres_using_cloudflare_proxy', '0');
	    echo '<input type="checkbox" id="fullres_using_cloudflare_proxy" name="fullres_using_cloudflare_proxy" value="1" ' . checked($using_cloudflare_proxy, '1', false) . ' /> <label for="fullres_using_cloudflare_proxy">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}
	
	function fullres_your_domain_field_callback() {
	    $your_domain = get_option('fullres_your_domain');
	    echo '<input type="text" id="fullres_your_domain" name="fullres_your_domain" value="' . esc_attr($your_domain) . '" placeholder="example.com" />';
	}
	
	function fullres_custom_path_name_field_callback() {
	    $custom_path_name = get_option('fullres_custom_path_name');
	    echo '<input type="text" id="fullres_custom_path_name" name="fullres_custom_path_name" value="' . esc_attr($custom_path_name) . '" /><br><small>' . esc_html__('Use anything for this path name that does not conflict with existing site structure.', 'fullres-wp') . '</small>';
	}

	function fullres_using_custom_domain_field_callback() {
	    $using_custom_domain = get_option('fullres_using_custom_domain', '0');
	    echo '<input type="checkbox" id="fullres_using_custom_domain" name="fullres_using_custom_domain" value="1" ' . checked($using_custom_domain, '1', false) . ' /> <label for="fullres_using_custom_domain">' . esc_html__('Enable', 'fullres-wp') . '</label>';
	}

	function fullres_custom_domain_field_callback() {
		$custom_domain = get_option('fullres_custom_domain', '');
		echo '<input type="text" id="fullres_custom_domain" name="fullres_custom_domain" value="' . esc_attr($custom_domain) . '" placeholder="example.com" />';
		echo '<br><small>' . wp_kses_post(__('Specify a custom domain for loading scripts. Optional and <strong>requires configuring</strong> in your <a href="https://docs.fullres.com/links/custom-domains" target="_blank">Fullres Dashboard</a> first.', 'fullres-wp')) . '</small>';
	}	

//ENQUEUE CUSTOM ADMIN SCRIPTs
	function fullres_admin_enqueue_scripts($hook) {
	    if ($hook != 'settings_page_fullres_analytics') {
	        return;
	    }
	    wp_enqueue_style('fullres-admin-style', plugin_dir_url(__FILE__) . 'admin.css', array(), '1.0.0');
	    wp_enqueue_script('fullres-admin-script', plugin_dir_url(__FILE__) . 'admin.js', array('jquery'), '1.0.0', true);
	}
	add_action('admin_enqueue_scripts', 'fullres_admin_enqueue_scripts');


//UPDATE CHECK SYSTEM
// Add the update check function
function fullres_check_for_updates() {
    $transient_key = 'fullres_plugin_update_info';
    $update_info = get_transient($transient_key);

    if ( false === $update_info ) {
        // Fetch the remote JSON file
        $response = wp_remote_get('https://docs.fullres.com/downloads/wordpress-plugin-update-info.json');

        if ( ! is_wp_error( $response ) && $response['response']['code'] == 200 ) {
            $update_info = json_decode( wp_remote_retrieve_body( $response ), true );
            // Cache the result for 12 hours
            set_transient( $transient_key, $update_info, 12 * HOUR_IN_SECONDS );
        } else {
            // Handle errors
            $update_info = null;
        }
    }

    return $update_info;
}


// Add admin notices
function fullres_admin_notices() {
    if ( ! current_user_can( 'update_plugins' ) ) {
        return;
    }

    $screen = get_current_screen();
    if ( $screen->id != 'settings_page_fullres_analytics' && $screen->id != 'plugins' ) {
        return;
    }

    // Check for updates
    $update_info = fullres_check_for_updates();
    $current_version = FULLRES_PLUGIN_VERSION;

    if ( $update_info && isset( $update_info['version'] ) && version_compare( $update_info['version'], $current_version, '>' ) ) {
        // Display the update notification
        echo '<div class="notice notice-warning"><p>';
        echo esc_html__( 'A new version of Fullres Analytics is available', 'fullres-wp' ). ' &rarr;';
        if ( isset( $update_info['download_url'] ) ) {
	        $upload_plugin_url = admin_url( 'plugin-install.php?tab=upload' );
            /* translators: %s: Version number */
            echo sprintf( ' <a href="' . esc_url( $update_info['download_url'] ) . '" target="_blank">' . esc_html__( 'Download %s', 'fullres-wp' ) . '</a>', esc_html( $update_info['version'] ) );
            echo ' then <a href="' . esc_url( $upload_plugin_url ) . '">upload it here</a>.';
        }
        echo '</p></div>';
    }
}
add_action( 'admin_notices', 'fullres_admin_notices' );
