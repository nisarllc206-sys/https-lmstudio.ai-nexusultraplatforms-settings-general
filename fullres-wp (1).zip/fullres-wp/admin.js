jQuery(document).ready(function($) {

	var customDomain = $('#fullres_custom_domain');

	function toggleCustomDomainOptions() {
        if ($('#fullres_using_custom_domain').is(':checked')) {
            customDomain.closest('tr').show();
        } else {
            customDomain.closest('tr').hide();
        }
    }

	var yourDomain = $('#fullres_your_domain'),
	yourPath = $('#fullres_custom_path_name');
	
    function toggleCloudflareOptions() {
        if ($('#fullres_using_cloudflare_proxy').is(':checked')) {
            yourDomain.closest('tr').show();
            yourPath.closest('tr').show();
        } else {
            yourDomain.closest('tr').hide();
            yourPath.closest('tr').hide();
        }
    }

    function generateRandomString(length) {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return result;
    }

    // Synchronize checkbox states
    function syncDomainCloudflareStates() {
        if ($('#fullres_using_custom_domain').is(':checked')) {
            $('#fullres_using_cloudflare_proxy').prop('checked', false).prop('disabled', true);
        } else {
            $('#fullres_using_cloudflare_proxy').prop('disabled', false);
        }

        if ($('#fullres_using_cloudflare_proxy').is(':checked')) {
            $('#fullres_using_custom_domain').prop('checked', false).prop('disabled', true);
        } else {
            $('#fullres_using_custom_domain').prop('disabled', false);
        }
    }

    // Pre-populate inputs on page load
    if (!yourDomain.val()) {
        yourDomain.val($('#fullres_site_domain').val());
    }

    if (!yourPath.val()) {
        yourPath.val(generateRandomString(10));
    }

    // Run on page load
    toggleCustomDomainOptions();
    toggleCloudflareOptions();
    syncDomainCloudflareStates();

    // Run when checkbox state changes
	$('#fullres_using_custom_domain').change(function() {
        toggleCustomDomainOptions();
        syncDomainCloudflareStates();
    });
    $('#fullres_using_cloudflare_proxy').change(function() {
        toggleCloudflareOptions();
        syncDomainCloudflareStates();
    });
});
