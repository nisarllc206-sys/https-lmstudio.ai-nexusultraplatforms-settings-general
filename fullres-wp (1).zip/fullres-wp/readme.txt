=== Fullres Analytics ===
Tags: analytics, privacy, GDPR, tracking, events
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.4.3
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Fullres is a privacy-first Google Analytics alternative that is simple to set up, easy to use, and packs powerful features.

== Description ==

**You need to create an account on [Fullres](https://fullres.com) to begin tracking analytics, which offers a generous Free plan as well as higher paid tiers. There's no credit card required to signup. This plugin is for implementing the related code snippet on your site.**

This plugin relies on the Fullres Analytics service to collect and process analytics data. When you use this plugin, data from your website is sent to Fullres Analytics for analysis and reporting.

== Features ==

**Lighting-fast Setup**

As soon as you create a Fullres account and install the related code on your website, your analytics dashboard will display valuable insights. It's shockingly fast to get up and running in minutes.

**GDPR Friendly**

We strongly believe in visitor privacy, and that's why Fullres does not include cookies, cross-site tracking, or other persistent identifiers. This means less worry for you and saying goodbye to Google Analytics.

**No Cookie Banners**

Clicking cookie banners or having to add them to your website is not the Internet we all hoped for. You don't need a cookie notice with Fullres because cookies are not used and visitor privacy is protected.

**Custom Metadata**

Want to see how many of your site's visitors are using ad blockers? Need to filter visitors by site plans? You can do that and so much more through the use of Fullres custom metadata.

**Powerful Event Tracking**

Events allow you to monitor specific user interactions on your website, such as button clicks and form submissions. It's a great way to better understand how users engage with your website.

**One Consolidated Platform**

Fullres combines multiple essential tools so there's no more juggling SaaS subscriptions. Monitor analytics, optimize SEO, and monetize content all on one platform.

== Third-Party Services ==

This plugin relies on the Fullres Analytics service for collecting and processing analytics data. When using this plugin, data from your website is sent to Fullres Analytics for analysis and reporting.

For more information, please visit:
- Fullres Analytics: [https://fullres.com](https://fullres.com)
- Terms of Use: [https://fullres.com/terms](https://fullres.com/terms)
- Privacy Policy: [https://fullres.com/privacy](https://fullres.com/privacy)

[Visit our website](https://fullres.com) to see all features.
